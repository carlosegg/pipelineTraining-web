#!/bin/bash 

. /home/develenv/bin/setEnv.sh
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi
function getMetricsTool(){
   if [ -f pom.xml ]; then
      echo "sonar"
   else
      echo "sonarRunner"
   fi
}

