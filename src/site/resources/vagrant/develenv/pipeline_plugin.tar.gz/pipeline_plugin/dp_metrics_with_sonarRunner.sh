#!/bin/bash

. /home/develenv/bin/setEnv.sh
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

source dp_version.sh

function isExecutedInDevelenv(){
   if [ "`id -nu`" == "develenv" ]; then
      isDevelenv="true"
   else
      isDevelenv="false"
   fi
}

function init(){
   _log "[INFO] Calculating metrics"
   JOB_HOME=`readlink -f ./`
   OUTPUT_DIR="$JOB_HOME/target/"
   mkdir -p $OUTPUT_DIR
}

function isPipelineJob(){
   [[ -z $PIPELINE_ID ]] && return 1 || return 0
}

function getProjectKey(){
   isPipelineJob
   [[ $?  == 1 ]] && \
      echo "${PROJECT_GROUPID}.${PROJECT_NAME}.${JOB_NAME}" && \
      return ;
   echo "${PIPELINE_ID}.${JOB_NAME}"
}

function getUrlCi(){
   echo $JENKINS_URL/job/$JOB_NAME
}

function execute(){
   init
   local thisFile=$PROJECT_PLUGINS/pipeline_plugin/dp_metrics_with_sonarRunner.sh
   local default_version_module="0.0"
   local errorCode
   local lineSeparator=`grep -n "############################### SONAR_RUNNER ###############################" $thisFile|grep -v "grep"|cut -d ':' -f1`
   local scmStats="true"
   local scmType="none"
   local scm
   local sonarFileconf=${OUTPUT_DIR}/sonar-project.properties
   local sonarProperty
   local versionModule
   sed 1,${lineSeparator}d $thisFile > ${sonarFileconf}
   sed -i s:"SONAR_KEY":"$JOB_NAME":g ${sonarFileconf}
   versionModule=$(getVersionModule)
   errorCode=$?
   [[ "$errorCode" != 0 ]] && versionModule=$default_version_module
   [[ "$errorCode" != 0 ]] && isPipelineJob && return $errorCode
   echo "sonar.projectVersion=$versionModule" >>${sonarFileconf}
   echo "sonar.projectKey=$(getProjectKey)" >>${sonarFileconf}
   scmType=$(getSCM)
   scm=$(scmUrl_${scmType})
   [[ "$scmType" == "mercurial" ]] && scmStats="false"
   if [ "$scmType" != "none"  -a  scmStats="true" ]; then
      echo "sonar.scm-stats.enabled=${scmStats}"  >> ${sonarFileconf}
      echo "sonar.scm.url=$scm">> ${sonarFileconf}
      echo "sonar.scm.enabled=true" >> ${sonarFileconf}
   else
      echo "sonar.scm-stats.enabled=false" >> ${sonarFileconf}
      echo "sonar.scm.enabled=false" >> ${sonarFileconf}
   fi
   echo "sonar.build-stability.url=Hudson:"$(getUrlCi) >> ${sonarFileconf}
   typeMetrics_${typeBuildProject} ${sonarFileconf}
   $PROJECT_HOME/app/jenkins/tools/Sonar_Runner/DEFAULT_SONAR_RUNNER/bin/\
sonar-runner -Dsonar.projectBaseDir=$WORKSPACE \
   -Dproject.settings=${sonarFileconf}
   errorCode=$?
   if [ "$errorCode" != "0" ]; then
      _log "[ERROR] Error in sonar Runner Execution"
      return $errorCode
   fi
   local url_sonar_resource="$(grep ^sonar.projectKey= ${sonarFileconf}|cut -d'=' -f2)"
   mkdir -p $(dirname "$WORKSPACE/../metrics/sonar")
   echo $url_sonar_resource py>>$WORKSPACE/../metrics/sonar
   _log "[INFO] Metrics calculated"
   return $errorCode
}

return $?
############################### SONAR_RUNNER ###############################
# Automatically generated with deployment pipeline plugin
sonar.projectName=SONAR_KEY
sonar.sources=./
sonar.dynamicAnalysis=reuseReports
sonar.exclusions=tests/**,**/tests/**

