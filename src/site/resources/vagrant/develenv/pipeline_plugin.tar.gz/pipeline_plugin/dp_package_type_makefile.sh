#!/bin/bash

source $(python -c 'import os,sys;print os.path.realpath(sys.argv[1])' $0/..)/dp_setEnv.sh
source $SET_ENV_FILE

if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

make clean
make rpm

