#!/bin/bash

. /home/develenv/bin/setEnv.sh
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

source dp_version.sh

function isExecutedInDevelenv(){
   if [ "`id -nu`" == "develenv" ]; then
      isDevelenv="true"
   else
      isDevelenv="false"
   fi
}

function init(){
   _log "[INFO] Calculating metrics"
   JOB_HOME=`readlink -f ./`
   OUTPUT_DIR="$JOB_HOME/target/"
   mkdir -p $OUTPUT_DIR
}

function isPipelineJob(){
   [[ -z $PIPELINE_ID ]] && return 1 || return 0
}

function getProjectKey(){
   isPipelineJob
   [[ $?  == 1 ]] && \
      echo "${PROJECT_GROUPID}.${PROJECT_NAME}.${JOB_NAME}" && \
      return ;
   echo "${PIPELINE_ID}.${JOB_NAME}"
}

function getUrlCi(){
   echo $JENKINS_URL/job/$JOB_NAME
}

function execute(){
   local mavenArguments=""
   init
   [[ -f target/site/cobertura/coverage.xml ]] && \
      mavenArguments="$mavenArguments -Dsonar.dynamicAnalysis=reuseReports"
  _log "[INFO] mvn sonar:sonar $mavenArguments"
   mvn sonar:sonar $mavenArguments
   return $?
}



