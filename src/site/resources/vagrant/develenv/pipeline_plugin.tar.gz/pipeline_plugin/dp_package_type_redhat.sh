#!/bin/bash

source $PROJECT_PLUGINS/pipeline_plugin/dp_setEnv.sh
source $SET_ENV_FILE
source $PROJECT_HOME/app/plugins/pipeline_plugin/dp_publishArtifactInOtherRepo.sh
source $PROJECT_PLUGINS/pipeline_plugin/dp_version.sh

function currentDir(){
   DIR="$PROJECT_PLUGINS/pipeline_plugin/"
}

currentDir
. $DIR/dp_build_ProjectType.sh
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

function help(){
   _message "Creación rpm
Uso:
   $0 [--debug] [--help] <version> <release>


PARÁMETROS:
   <version>  Versión del software que se está desarrollando
   <release>  Número de release
   --help: Esta pantalla de ayuda.
   --debug: Activa las opciones de debug

EJEMPLO:
   $0 --debug 1.0 20120606_224433
"
}

function packageError(){
   errorMessage="$1"
   _log "[ERROR] $errorMessage"
}

function exitPackage(){
   if [ "$1" != "" ]; then
      exit $1
   else
      exit 1
   fi
}

function helpError(){
   packageError "$1"
   help
   exitPackage "$2"
}

function exitError(){
   packageError "$1"
   exitPackage "$2"
}

function createChangeLog(){
   #Si no existe el changelog se genera a partir de los logs del SCM
   if [ "`cat $modifiedSpecFile|egrep \"^%changelog\"`" == "" ]; then
      if [ "$scmtype" == "mercurial" ]; then
         echo "%changelog" >> $modifiedSpecFile
         export authors=`hg log|grep "^user:" |uniq|sed s:"user\:\( \)*":"":g`
         echo "* `date "+%a %b %d %Y"` $authors" >> $modifiedSpecFile
         hg tip|grep "changeset:"|sed s:"changeset\:":"- revision\:  ":g >> $modifiedSpecFile
         hg log|grep "summary:"|sed s:"summary\:":"  * ":g >> $modifiedSpecFile
      fi
   fi
}

function checkSpecFile(){
   #Tests the mandatory sections and tags
   tags="License: Vendor: Summary: %description BuildArch:"
   for tag in $tags; do
      if [ "`cat $1|grep \"^${tag}\"|wc -l`" != "1" ]; then
         exitError "[$1] No tiene definido el tag [$tag]" 1
      fi
   done;
}


function changeSection(){
   sections="$1"
   substitute="$2"
   filtered=`echo $substitute|sed s/:/\\\\\\\:/g`
   for section in $sections; do
      line=$(expr `egrep -n "^%prep|^%install|^%build|^%description|^%files|^%doc|^%clean|^%changelog|^%pre|^%post|^%preun|^%postun" $modifiedSpecFile|grep -n "%${section}$"|cut -d':' -f1` + 1)
      if [ "$line" -gt 1 ]; then
         nextSection=`cat $auxTmpFile|head -n $line|tail -n 1|cut -d':' -f2`
         if [ "$substitute" != "scm.info" ]; then
            sed  -i s:"^${nextSection}":"$filtered\\n${nextSection}":g $modifiedSpecFile
         else
           echo "#!/bin/bash" > deleteme.spec.sh
           echo 'f2="$(<scm.info)"' >> deleteme.spec.sh
           echo "awk -vf2=\"\$f2\" '/^${nextSection}/{print f2;print;next}1' $modifiedSpecFile> deleteme.spec"  >> deleteme.spec.sh
           echo "mv deleteme.spec $modifiedSpecFile "  >> deleteme.spec.sh
           chmod 755 deleteme.spec.sh
           ./deleteme.spec.sh
           rm -Rf deleteme.spec.sh
         fi
      fi
   done;
}

function changeSections(){
   #exclude Defaults Files
   auxTmpFile="aux.spec.tmp"
   egrep -n "^%prep|^%install|^%build|^%description|^%files|^%doc|^%clean|^%changelog|^%pre|^%post|^%preun|^%postun" $modifiedSpecFile >$auxTmpFile
   changeSection "install build prep" "%_default_exclude_files"
   if ! [ -z "$BUILD_ID" ]; then
      changeSection "description" "----------------------------------Jenkins---------------------------------------"
      changeSection "description" "Build ID: $BUILD_ID"
      changeSection "description" "Build URL: $BUILD_URL"
      changeSection "description" "----------------------------------Develenv--------------------------------------"
      changeSection "description" "Version: $PROJECT_VERSION"
      changeSection "description" "----------------------------------rpmBuild--------------------------------------"
      changeSection "description"  "$rpmBuildCommand"
      changeSection "description" "-------------------------------------SCM----------------------------------------"
   fi
   getSCMInfo
   rm -Rf $auxTmpFile
}

function filterSpecFile(){
   if [[ "$PREFIX_PROJECT" != "" ]]; then
      sed s:"^Name\:.*":"Name\: $packageName\\n%define _project_name $PREFIX_PROJECT":g $specFile >>$modifiedSpecFile
      sed -i  s:"^%define project_user.*":"%define project_user $PREFIX_ORGANIZATION-$PREFIX_PROJECT":g $modifiedSpecFile
      sed -i  s:"^%define _prefix_.*":"%define _prefix_ /opt/$PREFIX_ORGANIZATION/$PREFIX_PROJECT":g $modifiedSpecFile
   else
      sed s:"^Name\:.*":"Name\: $packageName":g $specFile >>$modifiedSpecFile
      sed -i  s:"^%define _prefix_.*":"%define _prefix_ /opt":g $modifiedSpecFile
   fi
   if [ "`cat $modifiedSpecFile|grep \"^BuildRoot:\"`" == "" ]; then
      #Si no está definido el buildRoot se introduce (Workaround para Redhat 5)
      sed -i s:"^BuildArch\:":"BuildRoot\: %{_topdir}/BUILDROOT\\nBuildArch\:":g $modifiedSpecFile
   fi
   createChangeLog
   phases="prep build install clean pre post preun postun"
   for phase in $phases; do
      sed -i  s:"^%$phase\( \|\t\)*":"%${phase}":g $modifiedSpecFile
      sed -i  s:"^%$phase\$":"%$phase\\n%{_log_${phase}_init}":g $modifiedSpecFile
   done;
   changeSections
}

function getHostname(){
   IP=`LANG=C /sbin/ifconfig | grep "inet addr" | grep "Bcast" | awk '{ print $2 }' | awk 'BEGIN { FS=":" } { print $2 }' | awk ' BEGIN { FS="." } { print $1 "." $2 "." $3 "." $4 }'`
   MAC_ADDRESSES=`LANG=C /sbin/ifconfig -a|grep HWaddr|awk '{ print $5 }'`
   if [ "$IP" == "" ]; then
      echo -e "\nNo hay conexión de red. Introduce el nombre o la ip de la máquina: \c"
      read HOST
   else
      local j=0
      for i in $IP; do
         #Averiguamos si alguna IP tiene asignada nombre de red
         j=$(($j +1 ));
         temp=`LANG=C nslookup $i|grep "name = "|cut -d= -f2| sed 's/.//' | sed 's/.$//'`
         if [ "$temp" != "" ]; then
            HOST=$temp
            INTERNALIP=$i
            MAC_ADDRESS=`echo $MAC_ADDRESSES|cut -d' ' -f$j`
         fi
      done
      if [ "$HOST" == "" ]; then
         # Probablemente sea una conexión wifi, y no tenga asignada un nombre en el DNS
         HOST=`hostname`
         INTERNALIP=`echo $IP|cut -d' ' -f1`
         MAC_ADDRESS=`echo $MAC_ADDRESSES|cut -d' ' -f1`
         # Si no hay un nombre de hosts asignado
         if [ "$HOST" == "" ];then
            # Nos quedamos con la primera IP
            HOST=$INTERNALIP
         fi
      fi
   fi
}

function testParameters(){
    [[ "$*" =~ "--help" ]] && help && exit 0
    [[ "$*" =~ "--debug" ]] && [[ "$1" == "--debug" ]] && debug="true" && shift 1 || debug="false"
    [[ "$*" =~ "--debug" ]] && [[ "$1" != "--debug" ]] && helpError "El parámetro debug tiene que ir en primer lugar" 3
    if [ "$#" == "0" ]; then
       releaseModule=$(getReleaseModule)
       getVersionModule
       versionModule=$VERSION_PROJECT
    else
       if [ "$#" != "2" ]; then
          helpError "Número de parámetros incorrectos"
          exit 1
       fi
       versionModule=$1
       releaseModule=$2
    fi
}

function addRPMDirs(){
    local specFile=$1
    [[ $(dirname $packagerFile) == $PROJECT_HOME/* ]] && [[ "`id -un`" == "$PROJECT_USER" ]] && RPM_HOME=$HOME/app/repositories/rpms || RPM_HOME=$HOME/rpmbuild/RPMS
    mkdir -p $RPM_HOME
    # Fijamos que los SOURCES de los RPMS estén a la misma altura
    SOURCES_RPM_DIR=$(dirname $(dirname $specFile))
    echo -e "\n\
%define _rpm_repo_url http://${HOST}/repo\n\
%define _builddir %{_topdir}/BUILD\n\
%define _rpmdir $RPM_HOME\n\
%define _sourcedir %{_topdir}/../../${SOURCES_RPM_DIR}/SOURCES\n\
%define _specdir `dirname $modifiedSpecFile`\n\
%define _srcrpmdir %{_topdir}/../../src\n\
%define pipeline_plugin_version `cat $PROJECT_PLUGINS/pipeline_plugin/$VERSION_FILE|grep 'Version:'|awk '{ print $2 }'`" >$modifiedSpecFile
}

function getRpmName(){
   local specFile=$1
   local versionModule=$2
   local releaseModule=$3
   local parameters=$(cat $specFile |egrep "^Version:|^Release:|^BuildArch:|^Name:"\
                     |sort|awk '{print $2}')
   
   local version=$(echo $parameters|awk '{print $4}')
   # Si la version está en el .spec
   if [[ ! $version =~ .*%\{.*\}.* ]]; then
      versionModule=$version
   fi
   local release=$(echo $parameters|awk '{print $3}')
   # Si la release está en el .spec
   if [[ ! $release =~ .*%\{.*\}.* ]]; then
      releaseModule=$release
   fi
   local buildArch=$(echo $parameters|awk '{print $1}')
   local name=$(echo $parameters|awk '{print $2}')
   echo $name-$versionModule-$releaseModule.$buildArch.rpm
}


function createRPM(){
   specFile=$1
   rpmGeneratedName=""
   _log "Creating rpm $specFile"
   checkSpecFile $specFile
   packageName=`cat $specFile |egrep "^Name:"|awk {'print $2'}`
   local architecture=`cat $specFile |grep "^BuildArch:"|awk '{print $2}'`
   local fullName=$(getRpmName $specFile $versionModule $releaseModule)
   if ! [ -z $PREFIX_PROJECT ]; then
      packageName=${PREFIX_ORGANIZATION}-${PREFIX_PROJECT}-$packageName
      fullName=${PREFIX_ORGANIZATION}-${PREFIX_PROJECT}-$fullName
   fi
   rpm_name=${fullName/\.$architecture\.rpm}
   debug_dir=/var/tmp/rpm/${rpm_name}
   rm -Rf $debug_dir
   if [ "$?" != 0 ]; then
      exitError "No existen permisos de escritura en el directorio $debug_dir"
      exit 1
   fi
   mkdir -p $debug_dir
   if [ $? != 0 ]; then
      exitError "No se puede crear el directorio $debug_dir. Puede que pertenezca a otro usuario" 1
   fi
   rm -Rf ${debug_dir}
   mkdir -p ${debug_dir}
   modifiedSpecFile=${debug_dir}/$packageName.spec
   #Adding rpm_macros
   addRPMDirs $specFile
   #Test if rpm exists
   [[ -f $RPM_HOME/$architecture/$fullName ]] && \
       _log "[WARNING] $fullName already exits.This rpm will not regenerated" \
       && return 1;
   sed 1,${lineSeparator}d $packagerFile >> $modifiedSpecFile
   rpmBuildCommand="rpmbuild -v --clean  --define '_buildshell '/bin/bash --define '_topdir '${TOPDIR} --define 'versionModule '$versionModule --define 'releaseModule '$releaseModule $prePackageExtension -bb $modifiedSpecFile"
   filterSpecFile $specFile
   rm -Rf $TOPDIR
   mkdir -p $TOPDIR/BUILD
   _message "$rpmBuildCommand"
   echo "$rpmBuildCommand 2>$debug_dir/rpmbuild.error.log >$debug_dir/rpmbuild.log" >$debug_dir/rpmbuild.sh
   echo "
errorCode=\$?
echo rpmbuildExit [\$errorCode]
exit \$errorCode
" >>$debug_dir/rpmbuild.sh
   chmod u+x $debug_dir/rpmbuild.sh
   $debug_dir/rpmbuild.sh
   errorCode=$?
   if [ "$errorCode" != "0" ]; then
      cat $debug_dir/rpmbuild.error.log
      exitError "Error[$errorCode] en la generación de rpm a partir del fichero $specFile \n\
Puedes consultar los logs en el directorio $debug_dir" $errorCode
   else 
      _log "[SUCCESS] rpmbuild [$specFile]"
   fi
   rm -Rf $SOURCE_DIR/.error
   rpmGeneratedName=$(grep ^Wrote: $debug_dir/rpmbuild.log|grep "\.rpm$"|awk '{print $2}')
   if [ "$?" == "0" ]; then
      _message "[INFO] Rpm content: $rpmGeneratedName"
      _message "-------------------------------------------------------------------"
       rpm -qlp $rpmGeneratedName
      _message "-------------------------------------------------------------------"
   fi
}

function init(){
   LANG=C
   DEFAULT_PREFIX_ORGANIZATION="NA"
   getBuildTypeProject
   scmtype=$(getSCM)
   testParameters $*
   getHostname
   currentDir
   SOURCE_DIR=$PWD
   if [ "$typeBuildProject" == "maven" ]; then
      isMavenOk
   fi
   packagerFile="$DIR/dp_package_type_redhat.sh"
   lineSeparator=`grep -n "#### RPM MACROS ####" $packagerFile|grep -v "grep" |cut -d':' -f1`
}

function buildRPMS(){
   TOPDIR=${SOURCE_DIR}/target/.rpm
   rm -Rf $TOPDIR
   mkdir -p $TOPDIR
   # Genera un rpm por cada fichero de *.spec
   for specFile in `find "." -name "*.spec"|grep -v "target"|sort`;do
      createRPM "$specFile"
      if [ "$?" == "0" ]; then
         publishInOtherRepo $rpmGeneratedName
         if [ "$debug" == "true" ]; then
            _message "Logs de construcción de ${rpm_name}.${architecture}.rpm en $debug_dir"
         else
            rm -Rf $debug_dir
         fi
      fi
   done;
   if [ "$specFile" == "" ]; then
      exitError "No existe ningún fichero .spec" 1
   fi
}

function publishRPMS(){
   _log "[INFO] Updating rpm repo"
   architectures="noarch x86_64 i386 i686 src"
   for architecture in $architectures; do
      mkdir -p $RPM_HOME/$architecture
      createrepo -s sha -d --update $RPM_HOME/$architecture
   done;
}

function dp_prePackage() {
   prePackageExtension=""
   [ $(type prePackage 2>/dev/null|head -1 |wc -l) == 1 ] && _message "[INFO] PrePackage" && prePackage
}

function dp_postPackage() {
   [ $(type postPackage 2>/dev/null|head -1 |wc -l) == 1 ] && _message "[INFO] PostPackage" && postPackage
}

function checkIntegrity(){
   if [ "`echo $packagerFile|grep '^\./.*'`" != "" ]; then
      # Comprobamos si se trata del packager del pipeline o de una copiado.
      _log "[WARNING] Este script [$packagerFile] ha sido modificado a partir del script packager.sh del deployment pipeline."
      return;
   fi
   currentChecksum=$(cat $packagerFile |grep '^####Checksum:'|cut -d':' -f2)
   #head -n$(expr `cat dp_package_type_redhat.sh |grep -n '^####Checksum:'|cut -d ':' -f1` - 1) dp_package_type_redhat.sh|md5sum|awk '{print $1}'
   calculatedChecksum=$(head -n$(expr `cat $packagerFile |grep -n '^####Checksum:'|cut -d ':' -f1` - 1) $packagerFile|md5sum|awk '{print $1}')
   if [ "$currentChecksum" != "$calculatedChecksum" ]; then
      exitError "No se puede ejecutar [$packagerFile] porque existen modificaciones locales que no han sido entregadas en un repositorio.\n Copia [$packagerFile] en el repositorio de tu proyecto con el nombre package.sh" 1
   fi
}

function execute(){
   init $*
   checkIntegrity
   dp_prePackage
   buildRPMS
   dp_postPackage
   publishRPMS
}

function main(){
   [ "$(basename $0)" == "dp_package_type_redhat.sh" ] && execute $* && exit $?
}
currentDir
VERSION_FILE="VERSION.txt"

if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   main --debug $*
else
   main $*
fi
return $?
#### RPM MACROS ####
%define _do_check ERROR_VALUE=`echo $?`;if [ $ERROR_VALUE != "0" ]; then exit -1;fi
%define _rpm_name %{name}-%{version}-%{release}
%define _debug_dir /var/tmp/rpm/%{_rpm_name}
# START: MACROS DE LOGS
%define _default_log_color_pre \\033[47m\\033[1;34m
%define _default_log_color_suffix \\033[0m\\\\n
%define _error_color \\033[47m\\033[1;31m
%define _log _message(){\
   [[ "\$1" =~ "[ERROR]" ]] && messageColor="%{_error_color}" || messageColor="%{_default_log_color_pre}"\
   echo -en "${messageColor}\$1%{_default_log_color_suffix}\n"\
}\
_log(){\
   _message "[`date '+%Y-%m-%d %X'`] \$1"\
}
%define _log_init %{_log}\
_log "==== Init ====[env -->%{_debug_dir}/env_${logPhase}] [script --> %{_debug_dir}/${logPhase}]"\
%{__mkdir_p} %{_debug_dir}\
env >%{_debug_dir}/env_${logPhase}\
%{__cp} $0 %{_debug_dir}/${logPhase}
%define _log_prep logPhase="PREP"
%define _log_prep_init %{_log_prep}\
%{_log_init}
%define _log_clean logPhase="CLEAN"
%define _log_clean_init %{_log_clean}\
%{_log_init}
%define _log_build logPhase="BUILD"
%define _log_build_init %{_log_build}\
%{_log_init}
%define _log_install logPhase="INSTALL"
%define _log_install_init %{_log_install}\
%{_log_init}
%define _log_pre logPhase="PRE-INSTALL"
%define _log_pre_init %{_log_pre}\
%{_log_init}
%define _log_post logPhase="POST-INSTALL"
%define _log_post_init %{_log_post}\
%{_log_init}
%define _log_preun logPhase="PRE-UNINSTALL"
%define _log_preun_init %{_log_preun}\
%{_log_init}
%define _log_postun logPhase="POST-UNINSTALL"
%define _log_postun_init %{_log_postun}\
%{_log_init}
# END: MACROS DE LOGS

%define _default_exclude_files \
cd $RPM_BUILD_ROOT\
exludeFiles=".svn .svnignore .cvs .cvsignore .hg .hgignore .git .gitignore .classpath .settings .project *.bak *.pyc *.*~"\
for excludeFile in $exludeFiles; do\
   rm -rf `find . -name "$excludeFile"`\
done;\
cd -

####Checksum:23380a6bbbcf416e8ad655653b30eaf6
