#!/bin/bash
REMOTE_TARGET_DIR=/home/develenv/temp/repos
#REMOTE_HOST_REPO=ci-pipeline
#REMOTE_USER_REPO=develenv

