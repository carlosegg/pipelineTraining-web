#!/bin/bash

. /home/develenv/bin/setEnv.sh
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

function isExecutedInDevelenv(){
   if [ "`id -nu`" == "develenv" ]; then
      isDevelenv="true"
   else
      isDevelenv="false"
   fi
}


function execute(){
   local mavenArguments=""
   sed 1,`expr $(cat pom.xml|grep -n "<distributionManagement>"|cut -d':' -f1) - 1`d pom.xml >.deleteme 2>/dev/null
   if [ "$?" == "0" ]; then
      sed -i `expr $(cat .deleteme|grep -n "</distributionManagement>"|cut -d':' -f1) + 1`,10000d .deleteme 2>/dev/null
      if [ "`cat .deleteme|grep \"</site>\"`" != "" ]; then
         mavenArguments="$mavenArguments site:site site:deploy"
      fi
   fi
   rm -Rf .deleteme
   if [ "$mavenArguments" != "" ]; then
      _log "[INFO] mvn $mavenArguments"
      mvn $mavenArguments
   fi
}

isExecutedInDevelenv
if [ "$isDevelenv" == "false" ]; then
   execute
fi

