#!/bin/bash
. /home/develenv/bin/setEnv.sh
. $PROJECT_PLUGINS/pipeline_plugin/createPipeline.sh
function help(){
   echo "Uso: $0 <organization> <project-name> <version> <module [module]*> <enviroment [enviroment]*> <adminUser> [--help]"
   echo "Creación del deployment pipeline de un proyecto"
   echo ""
   echo ""
   echo "EJEMPLO:"
   echo "    $0 \"ss\" \"webCalculator\" \"1.0\" \"frontend backend\" \"ci qa thirdparty demo\" \"root\"" 
   echo ""
   echo "Más información en http://code.google.com/p/develenv-pipeline-plugin"
}
helpParameter $*
if [ "$#" != 6 ]; then
   errorParameters "Incorrect number of parameters"
   help
else
   createProject "$1" "$2" "$3" "$4" "$5" "$6"
fi


