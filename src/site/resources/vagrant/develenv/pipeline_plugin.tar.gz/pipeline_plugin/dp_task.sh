#!/bin/bash
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

source $(python -c 'import os,sys;print os.path.realpath(sys.argv[1])' $0/..)/dp_setEnv.sh
source $SET_ENV_FILE

typeTasks="build compile unitTest metrics docs"
function help(){
   _message "dp_task [$typeTasks]"
}

function init(){
   _log "[INFO]--------------------------"
   _log "[INFO] INIT $1 $2 task"
   _log "[INFO]--------------------------"
}

function finalizeWithError(){
   _log "[ERROR]--------------------------"
   _log "[ERROR] $1 $2 task failed"
   _log "[ERROR]--------------------------"

}

function testParameters(){
   [[ $# == 1 ]] && echo $typeTasks|grep $1 && return 0;
   if [ $# != 1 ]; then
      _log "[ERROR] Incorrect parameters"
   else
      _log "[ERROR] $1 isn't a task"
   fi
   help
   return 1
}
testParameters $*
[[ $? != 0 ]] && exit 1 
task=$1
. $PROJECT_PLUGINS/pipeline_plugin/dp_build_ProjectType.sh
getBuildTypeProject
errorCode=$?
if [ "$errorCode" != 0 ]; then
   exit $errorCode
fi
if [ "`which dp_${task}_type_${typeBuildProject}.sh`" == "" ]; then
    _log "[WARNING] Default [${task}] task doesn't exist for \
[${typeBuildProject}] project type. Is it correct?"
fi


if [ -f ${task}.sh  -a ! -f .${task}.sh ]; then
   if [ -x ${task}.sh ]; then
      _log "[INFO] Executing custom ${task}[./${task}.sh]"
      init ${task} "custom"
      . ./${task}.sh
   else
      _log "[ERROR] [${task}.sh] haven't execution permissions"
      finalizeWithError ${task} "custom"
      exit 1
   fi
else
   if [ "$(which dp_${task}_type_${typeBuildProject}.sh)" != "" ]; then
      _log "[INFO] Executing default ${task}[dp_${task}_type_${typeBuildProject}.sh]"
      init ${task} "default"
      . dp_${task}_type_${typeBuildProject}.sh
      execute
      errorCode=$?
      if [ "$errorCode" != "0" ]; then
         finalizeWithError ${task} "default"
         exit $errorCode
      fi
   fi
fi
