#!/bin/bash
. /home/develenv/bin/setEnv.sh
. $PROJECT_PLUGINS/pipeline_plugin/createPipeline.sh
function help(){
   echo "Uso: $0 <project-name> <module>[--help]"
   echo "Creación de un módulo dentro del deployment pipeline de un proyecto. Para crear un módulo es necesario que el proyecto esté creado anteriormente."
   echo ""
   echo ""
   echo "EJEMPLO:"
   echo "    $0 \"webCalculator\" \"frontend\" "
   echo ""
   echo "Más información en http://code.google.com/p/develenv-pipeline-plugin"
}

helpParameter $*
if [ "$#" != 2 ]; then
   errorParameters "Incorrect number of parameters"
   help
else
   createModule "$1" "$2"
fi

