#!/bin/bash
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

. /home/develenv/bin/setEnv.sh

. $PROJECT_PLUGINS/pipeline_plugin/dp_task.sh "metrics"
errorCode=$?
if [ "$errorCode" != 0 ]; then
   _log "[ERROR] In metric phase"
   exit $errorCode
fi
dp_build_metricsOk.sh
errorCode=$?
if [ "$errorCode" != 0 ]; then
   _log "[ERROR] The metrics are worst than last execution"
    exit $errorCode
fi
