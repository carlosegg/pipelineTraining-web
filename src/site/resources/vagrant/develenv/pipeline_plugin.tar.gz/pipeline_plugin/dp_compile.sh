#!/bin/bash
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

. /home/develenv/bin/setEnv.sh

. $PROJECT_PLUGINS/pipeline_plugin/dp_task.sh "compile"

