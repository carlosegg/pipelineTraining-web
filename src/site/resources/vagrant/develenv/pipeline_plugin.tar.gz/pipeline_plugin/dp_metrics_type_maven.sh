#!/bin/bash 

. /home/develenv/bin/setEnv.sh
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

source dp_metrics_tool.sh
source dp_metrics_with_$(getMetricsTool).sh

isExecutedInDevelenv
if [ "$isDevelenv" == "false" ]; then
   execute
fi
return $?
