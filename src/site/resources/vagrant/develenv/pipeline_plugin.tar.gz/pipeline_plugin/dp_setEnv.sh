#!/bin/bash
function isExecutedInDevelenv(){
   if [ "`id -nu`" == "develenv" ]; then
      isDevelenv="true"
   else
      isDevelenv="false"
   fi
   export isDevelenv
}

function setupEnv(){
   local dirInstallationPipelinePlugin
   local isDevelenvSource
   local pipelinePluginPath="deploymentPipeline/src/main/deploymentPipeline/plugin/app/plugins/pipeline_plugin"
   isExecutedInDevelenv
   if [ "$isDevelenv" == "true" ]; then
      PROJECT_HOME=/home/develenv
      SET_ENV_FILE=$PROJECT_HOME/bin/setEnv.sh
   else
      dirInstallationPipelinePlugin=$(python -c 'import os,sys;print os.path.realpath(sys.argv[1])' $0)
      isDevelenvSource=$(echo $dirInstallationPipelinePlugin|\
        grep $pipelinePluginPath)
      if [ "$isDevelenvSource" != "" ]; then
         PROJECT_HOME=$(python -c 'import os,sys;print os.path.realpath(sys.argv[1])' $isDevelenvSource/../../../../)
         SET_ENV_FILE=$(python -c 'import os,sys;print os.path.realpath(sys.argv[1])' $PROJECT_HOME/../../../../../src/main/scripts/setEnv.sh)
      else
         PROJECT_HOME=$(python -c 'import os,sys;print os.path.realpath(sys.argv[1])' ../../../)
         if [ "$DEVELENV_SOURCE_HOME" != "" -a -f "$DEVELENV_SOURCE_HOME/src/main/scripts/setEnv.sh" ]; then
           SET_ENV_FILE=$DEVELENV_SOURCE_HOME/src/main/scripts/setEnv.sh
           PROJECT_HOME=$DEVELENV_SOURCE_HOME/$pipelinePluginPath
         else
            echo "[ERROR] DEVELENV_SOURCE_HOME must be defined."
            exit 1
         fi
      fi
   fi
   export PROJECT_HOME
   export PROJECT_USER=develenv
   export PROJECT_NAME=develenv
   export PROJECT_GROUPID=develenv
   export PROJECT_PLUGINS=$PROJECT_HOME/app/plugins
   export SET_ENV_FILE
   export PATH=$PROJECT_PLUGINS/pipeline_plugin:$PATH
}

setupEnv

