#!/bin/bash
source $(python -c 'import os,sys;print os.path.realpath(sys.argv[1])' $0/..)/dp_setEnv.sh
source $SET_ENV_FILE

if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

which dp_package_ProjectType.sh
[ "$?" != 0 ] && _log "[ERROR] $0 se está ejecutando fuera de develenv. Añade al 
path la ruta $PROJECT_PLUGINS/pipeline_plugin" && exit 1

. dp_package_ProjectType.sh

getPackageTypeProject
errorCode=$?
if [ "$errorCode" != 0 ]; then
   exit $errorCode
fi
for aTypePackageProject in $typePackageProject; do
   if [ "`which dp_package_type_${aTypePackageProject}.sh`" == "" ]; then
      _log "[ERROR] No existe un procedimiento para hacer el package de un proyecto tipo [${aTypePackageProject}]"
      exit 1
   fi
   _log "[INFO] Executing default package[dp_package_type_${aTypePackageProject}.sh]"
   dp_package_type_${aTypePackageProject}.sh
   errorCode=$?
   if [ "$errorCode" != "0" ]; then
      exit $errorCode
   fi
done;
exit $errorCode

