#!/bin/bash

. /home/develenv/bin/setEnv.sh
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

source dp_build_type_default.sh

function isExecutedInDevelenv(){
   if [ "`id -nu`" == "$PROJECT_NAME" ]; then
      isDevelenv="true"
   else
      isDevelenv="false"
   fi
}

isExecutedInDevelenv
if [ "$isDevelenv" == "false" ]; then
   execute
fi
