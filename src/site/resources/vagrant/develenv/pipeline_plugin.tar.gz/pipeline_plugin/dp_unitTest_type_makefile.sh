#!/bin/bash

. /home/develenv/bin/setEnv.sh
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

function isExecutedInDevelenv(){
   if [ "`id -nu`" == "develenv" ]; then
      isDevelenv="true"
   else
      isDevelenv="false"
   fi
}

function execute(){
   local mavenArguments=""
   [[ "$(grep "cobertura-maven-plugin" pom.xml)" != "" ]] && \
      mavenArguments="$mavenArguments cobertura:cobertura -Dcobertura.report.format=xml"
   _log "[INFO] mvn install $mavenArguments"
   mvn install $mavenArguments
}

isExecutedInDevelenv
if [ "$isDevelenv" == "false" ]; then
   execute
fi

