#!/bin/bash
source $PROJECT_PLUGINS/pipeline_plugin/dp_setEnv.sh
source $SET_ENV_FILE
source $PROJECT_PLUGINS/pipeline_plugin/get_git_version_string.sh

VERSION_FILE="VERSION.txt"

if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi
function packageError(){
   errorMessage="$1"
   _log "[ERROR] $errorMessage"
}

function exitPackage(){
   if [ "$1" != "" ]; then
      exit $1
   else
      exit 1
   fi
}

function exitError(){
   packageError "$1"
   exitPackage "$2"
}

function scmUrl_git(){
   echo "scm:git:"$(grep "url =" .git/config|sed s:".*=":"":g|awk '{print $1}')
}

function scmUrl_mercurial(){
   echo "scm:hg:"$(tail -1 .hg/hgrc|sed s:".*=":"":g|awk '{print $1}')
}

function scmUrl_subversion(){
   echo "scm:svn:"$(svn info|grep "^URL:"|awk '{print $2}')
}

function scmUrl_none(){
   echo ""
}

function scm_gitInfo(){
   pushd . >/dev/null
   # Find base of git directory
   while [ ! -d .git ] && [ ! `pwd` = "/" ]; do cd ..; done
   # Show various information about this git directory
   if [ -d .git ]; then
      echo "== Remote URL: `git remote -v`" >>scm.info
      echo "== Remote Branches: ">>scm.info
      git branch -r >>scm.info
      echo >>scm.info
      echo "== Local Branches:" >>scm.info
      git branch >>scm.info
      echo >>scm.info
      echo "== Configuration (.git/config)" >>scm.info
      cat .git/config >>scm.info
      echo >>scm.info
      echo "== Most Recent Commit" >>scm.info
      git --no-pager log --max-count=1 >>scm.info
      echo >>scm.info
      echo "Type 'git log' for more commits, or 'git show' for full commit details." >>scm.info
   else
      echo "Not a git repository." >>scm.info
   fi
   popd >/dev/null
}

function scm_mercurialInfo(){
   if [ -d .hg ]; then
      echo "== Remote URL: `hg paths`" >>scm.info
      echo "== Remote Branches: ">>scm.info
      hg branches >>scm.info
      echo >>scm.info
      echo "== Current Branch: ">>scm.info
      hg branch >>scm.info
      echo >>scm.info
      echo "== Most Recent Commit" >>scm.info
      hg log -l 1 -b `hg branch` >>scm.info
   else
     echo "Not a mercurial repository." >>scm.info
   fi
}

function scm_subversionInfo(){
   svn info >>scm.info
   revision="`echo $(svn info .|egrep "^Revision:"|sed s:"Revision\: ":"":g)`"
   if [ "$(svn propget svn:externals .)" != "" ]; then
      echo "External Links in the root of the repo" >>scm.info
      svn propget svn:externals . > .borrame
      while read line
         do
         url=$(echo $line |awk '{print $1}')
         if [[ "$url" != "" ]]; then
            echo $(svn info $url|egrep "^URL:|^Revision:"|sed s:"URL\: ":"":g|sed s:"Revision\: ":"":g) >>scm.info
            revision="$revision `echo $(svn info $url|egrep "^Revision:"|sed s:"Revision\: ":"":g)`"
         fi
      done < ".borrame"
      rm -Rf .borrame
   fi
}

function scm_noneInfo(){
   echo "[WARNING] this code isn't stored in any scm repository" >>scm.info
}

function get_scm_revision_subversion(){
   revision="`echo $(svn info .|egrep "^Revision:"|sed s:"Revision\: ":"":g)`"
   if [ "$(svn propget svn:externals .)" != "" ]; then
      svn propget svn:externals . > .borrame
      while read line
         do
         url=$(echo $line |awk '{print $1}')
         if [[ "$url" != "" ]]; then
            revision="$revision `echo $(svn info $url|egrep "^Revision:"|sed s:"Revision\: ":"":g)`"
         fi
      done < ".borrame"
      rm -Rf .borrame
   fi
   echo $(expr `echo $revision|sed s:" ":" + ":g`) 
}

function get_default_scm_revision(){
   date '+%Y%m%d_%H%M%S'
}
function get_scm_revision_mercurial(){
   get_default_scm_revision
}

function get_scm_revision_git(){
   . get_git_version_string.sh
   if [[ $(is_pdi_compliant) ]]; then
     echo $(get_revision) 
   else
     echo $(date '+%Y%m%d_%H%M%S').$(git --no-pager log --max-count=1|grep "^commit"|awk '{print $2}')
   fi
}

function get_scm_revision_none(){
   get_default_scm_revision
}

function getSCMInfo(){
   rm -Rf scm.info
   echo "[$scmtype]" >scm.info
   scm_${scmtype}Info
   changeSection "description" "scm.info"
   rm -Rf scm.info
}


function getSCM(){
   local source_dir=$PWD
   local scmtype="none"
   if [ "`ls -a $source_dir|grep .hg`" != "" ]; then
      scmtype="mercurial"
   else
      if [ "`ls -a $source_dir|grep .svn`" != "" ]; then
         scmtype="subversion"
      else
         if [ "`ls -a $source_dir|grep .git`" != "" ]; then
            scmtype="git"
         fi
     fi
   fi
   echo $scmtype
}

function versionFileError(){
   exitError "$1
Project: webCalculator
Module: frontend
Version: 1.1
Organization: SoftwareSano
PrefixOrganization: ss" $2
}

function getVersionProperties(){
   PREFIX_PROJECT=`grep "^Project:" $VERSION_FILE|sed s:"^Project\:":"":g|awk ' {print $1} '`
   if [ "$PREFIX_PROJECT" == "" ]; then
      versionFileError "No se ha definido el nombre del proyecto" 1
   fi
   PREFIX_ORGANIZATION=`grep "^PrefixOrganization:" $VERSION_FILE|sed s:"^PrefixOrganization\:":"":g|awk ' {print $1} '`
   if [ "$PREFIX_ORGANIZATION" == "" ]; then
      versionFileError "No se ha definido la organización a la que pertenece este proyecto" 1
   fi
   MODULE_PROJECT=`grep "^Module:" $VERSION_FILE|sed s:"^Module\:":"":g|awk ' {print $1} '`
   if [ "$MODULE_PROJECT" == "" ]; then
      versionFileError "No se ha definido el nombre del módulo" 1
   fi
   VERSION_PROJECT=`grep "^Version:" $VERSION_FILE|sed s:"^Version\:":"":g|awk ' {print $1} '|sed s:"-SNAPSHOT":"":g`
   if [ "$VERSION_PROJECT" == "" ]; then
      versionFileError "No se ha definido la version del proyecto" 1
   fi
}

function isMavenOk(){
   if [ -f $VERSION_FILE ]; then
         getVersionProperties
   else
      PREFIX_PROJECT=`grep "<artifactId>" pom.xml|head -1|sed s:"</\?artifactId>":"":g|awk ' {print $1} '`
      VERSION_PROJECT=`grep "<version>" pom.xml|head -1|sed s:"</\?version>":"":g|awk ' {print $1} '|sed s:"-SNAPSHOT":"":g`
      PREFIX_ORGANIZATION=`grep "<organization.acronym>" pom.xml|head -1|sed s:"</\?organization.acronym>":"":g|awk ' {print $1} '`
      [[ -z $PREFIX_ORGANIZATION ]] && PREFIX_ORGANIZATION="$DEFAULT_PREFIX_ORGANIZATION" && _log "[WARNING] No se ha definido una organización para este componente. Por defecto se asigna la organización [$DEFAULT_PREFIX_ORGANIZATION] "
   fi
}

function mavenVersion(){
   VERSION_PROJECT=`grep "<version>" pom.xml|head -1|sed s:"</\?version>":"":g|awk ' {print $1} '|sed s:"-SNAPSHOT":"":g`
   echo $VERSION_PROJECT
}


function getVersionModule(){
   if [ -f $VERSION_FILE ]; then
      getVersionProperties
   else
      if [ "$typeBuildProject" == "maven" ]; then
         VERSION_PROJECT=$(mavenVersion)
      elif [ "$typeBuildProject" == "python" -a  "$(is_pdi_compliant)" == "1" ]; then
         VERSION_PROJECT=$(get_version)
      else
         versionFileError "Es necesario definir un $VERSION_FILE del siguiente estilo:" 1
      fi
   fi
   echo $VERSION_PROJECT
}

function getReleaseModule(){
   echo $(get_scm_revision_${scmtype})
}




