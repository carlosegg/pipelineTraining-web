#!/bin/bash
. /home/develenv/bin/setEnv.sh
function execute(){
   _log "[ERROR] Tipo de proyecto irreconocible"
   return 1
}

function isExecutedInDevelenv(){
   if [ "`id -nu`" == "$PROJECT_NAME" ]; then
      isDevelenv="true"
   else
      isDevelenv="false"
   fi
}


isExecutedInDevelenv
if [ "$isDevelenv" == "false" ]; then
   execute
   exit $?
fi



