#!/bin/bash
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

source $(python -c 'import os,sys;print os.path.realpath(sys.argv[1])' $0/..)/dp_setEnv.sh
source $SET_ENV_FILE
source $PROJECT_PLUGINS/pipeline_plugin/dp_task.sh "build"
errorCode=$?
if [ "$errorCode" != 0 ]; then
   exit $errorCode
fi
dp_build_metricsOk.sh
exit $?

