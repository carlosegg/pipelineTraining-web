#!/bin/bash
source $(python -c 'import os,sys;print os.path.realpath(sys.argv[1])' $0/..)/dp_setEnv.sh
source $SET_ENV_FILE

if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

function isPackageTypeCustom(){
   local dpSetupFile=$(find . -name ".dpSetup"|head -1)
   if [ "$dpSetupFile" != "" ]; then 
      source $dpSetupFile
      typePackageProject="$DP_PACKAGE_TYPE ${typePackageProject}"
   fi
}

function isPackageTypeRedhat(){
   if [ "`find . -name \"*.spec\"`" != "" ]; then
      typePackageProject="redhat ${typePackageProject}"
   fi
}

function isPackageTypeDebian(){
   if [ "`find -maxdepth 1 -name \"*.deb\"`" != "" ]; then
      typePackageProject="debian ${typePackageProject}"
   fi
}

function isPackageTypeMakefile(){
    if [ "`find -maxdepth 1 -name \"Makefile\"`" != "" ]; then
       if [ "$(grep \"^rpm\:\" Makefile)" != "" ]; then
          typePackageProject="makefile ${typePackageProject}"
       fi
    fi
}

function getPackageType(){
   currentFile=$(which $_)
   typePackageProject=""
   for packageType in `cat $currentFile|grep "^function isPackageType.*()"|awk '{ print $2 }'|sed s:"(.*":"":g`;do
      $packageType
   done;
   if [ "$typePackageProject" != "" ]; then
      return 0
   fi
   return 1
}

function getPackageTypeProject(){
   getPackageType
   errorCode=$?
   if [ "$errorCode" != "0" ]; then
      _log "[ERROR] Faltan definir la configuración para la paquetización (Ej: .spec para redhat)"
      return $errorCode
   else
      if [ "$typePackageProject" == "" ]; then
         typePackageProject="withoutType"
      fi
      return $errorCode
   fi
}
