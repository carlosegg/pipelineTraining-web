#!/bin/bash 


source $(python -c 'import os,sys;print os.path.realpath(sys.argv[1])' $0/..)/dp_setEnv.sh
source $SET_ENV_FILE

if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

function typeMetrics_makefile(){
   _log "[WARNING] Makefile metrics aren´t implemented"
}
source dp_metrics_tool.sh
source dp_metrics_with_$(getMetricsTool).sh

if [ "$isDevelenv" == "false" ]; then
   execute
fi
errorCode=$?
return $?
