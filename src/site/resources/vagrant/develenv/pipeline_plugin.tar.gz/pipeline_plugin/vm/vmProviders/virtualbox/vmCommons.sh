#!/bin/bash
SSH_COMMAND="ssh $SSH_OPTIONS carlosg@ironman.hi.inet"
DOMAIN=".hi.inet"

