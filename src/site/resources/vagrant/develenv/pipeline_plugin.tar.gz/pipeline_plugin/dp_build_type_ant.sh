#!/bin/bash
. /home/develenv/bin/setEnv.sh
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi
function metricsOk(){
   _log "[WARNING] The metrics aren't configure"
}

function execute(){
   ant
   errorCode="$?"
   if [ "$errorCode" == "0" ]; then
      metricsOk
      errorCode="$?"
   fi
   return $errorCode
}

function isExecutedInDevelenv(){
   if [ "`id -nu`" == "$PROJECT_NAME" ]; then
      isDevelenv="true"
   else
      isDevelenv="false"
   fi
}


isExecutedInDevelenv
if [ "$isDevelenv" == "false" ]; then
   execute
fi

