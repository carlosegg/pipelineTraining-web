#!/bin/bash
function isBuildTypeCustom(){
   local dpSetupFile=$(find . -name ".dpSetup"|head -1)
   if [ "$dpSetupFile" != "" ]; then 
      source $dpSetupFile
      typeBuildProject="$DP_BUILD_TYPE"
   fi
}

function isBuildTypeMaven(){
   if [ "`find -maxdepth 1 -name \"pom.xml\"`" != "" ]; then
      typeBuildProject="maven"
   fi
}

function isBuildTypeAnt(){
   if [ "`find -maxdepth 1 -name \"build.xml\"`" != "" ]; then
      typeBuildProject="ant"
   fi
}

function isBuildTypeMakefile(){
    if [ "`find -maxdepth 1 -name \"Makefile\"`" != "" ]; then
        typeBuildProject="makefile"
    fi
}

function isBuildTypeStaticWeb(){
    if [ -d "$PWD/src/main/webapp" ]; then
       typeBuildProject="staticWeb"
    fi
}

function isBuildTypePython(){
    if [ -f "$PWD/setup.py" ]; then
       typeBuildProject="python"
       return;
    fi
    # Es un proyect django
    [[ "$(find . -name "manage.py" -exec grep -l django {} \;)" != "" ]] && \
    typeBuildProject="python"
}

# Maybe the project doesn't need a build. Only package. 
# At the moment only supports rpm.
function isBuildTypeProjectWithoutBuild(){
    [[ "$(find . -name "*.spec")" != "" ]] && \
    typeBuildProject="projectWithoutBuild"
}

function getBuildType(){
   for buildType in `cat $PROJECT_PLUGINS/pipeline_plugin/dp_build_ProjectType.sh|grep "^function isBuildType.*()"|awk '{ print $2 }'|sed s:"(.*":"":g`;do
      typeBuildProject=""
      $buildType
      if [ "$typeBuildProject" != "" ]; then
         return 0
      fi
   done;
   return 1
}

function getBuildTypeProject(){
   getBuildType
   errorCode=$?
   if [ "$errorCode" != "0" ]; then
      _log "[ERROR] This type project doesn't fit into the pipeline type \
       projects. Please visit \
       http://develenv.softwaresano.com/deploymentPipeline/dp_build.html \
       to see if the pipeline automatically supports such \
       projects." 
      return $errorCode
   else
      if [ "$typeBuildProject" == "" ]; then
         typeBuildProject="withoutType"
      fi
      return $errorCode
   fi
}
