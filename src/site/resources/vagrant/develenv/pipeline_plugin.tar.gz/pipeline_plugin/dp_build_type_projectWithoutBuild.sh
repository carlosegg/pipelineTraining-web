#!/bin/bash

. /home/develenv/bin/setEnv.sh
if [ "$DEBUG_PIPELINE" == "TRUE" ]; then
   set -x
else
   set +x
fi

function execute(){
   _log "[WARNING] This project doesn't need build phase."
}

function isExecutedInDevelenv(){
   if [ "`id -nu`" == "$PROJECT_NAME" ]; then
      isDevelenv="true"
   else
      isDevelenv="false"
   fi
}

isExecutedInDevelenv
if [ "$isDevelenv" == "false" ]; then
   execute
fi
